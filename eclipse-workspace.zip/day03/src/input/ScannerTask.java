package input;

import java.util.Scanner;

public class ScannerTask {
	public static void main(String[] args) {

//		[실습]
//		두 정수를 입력한 뒤 덧셈 결과를 출력하라
//		단, next()만 사용.
		
		
		Scanner sc = new Scanner(System.in);//자동 import 단축키 = ctrl + shrft + o
		int num1 = 0, num2 = 0;
		
		System.out.print("첫번째 정수 : ");
		num1 = Integer.parseInt(sc.next());
		
		System.out.print("두번째 정수 : ");
		num2 = Integer.parseInt(sc.next());
		
		System.out.printf("%d + %d = %d", num1, num2, num1+num2);
		
		
		
		/*
		 * Scanner sc = new Scanner(System.in);//자동 import 단축키 = ctrl + shrft + o
		 * //int num1 = 0, num2 = 0;
		 * String num1 = null, num2 = null;
		 * 
		 * System.out.print("첫번째 정수 : "); num1 = sc.next();
		 * 
		 * System.out.print("두번째 정수 : "); num2 = sc.next();
		 * 
		 * int result = (Integer.parseInt(num1)) +(Integer.parseInt(num2));
		 * System.out.println("두 정수의 합 : " + result);
		 */
		
		
		
		/* [내가 짠 소스]
		 * Scanner sc = new Scanner(System.in);
		 * 
		 * int firstNum = 0; int secNum = 0;
		 * 
		 * System.out.println("첫번째 값을 입력하세요 : ");
		 * firstNum = sc.next();
		 * 
		 * System.out.println("두번째 값을 입력하세요 : ");
		 * secNum = sc.next();
		 * 
		 * System.out.println(firstNum + secNum);
		 */
		
	}
}
