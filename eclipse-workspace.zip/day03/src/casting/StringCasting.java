package casting;

public class StringCasting {
	public static void main(String[] args) {
		
		String num = "123";
		System.out.println(num + 100); //연결
		System.out.println(Integer.parseInt(num)); //연산
		
		int result = Integer.parseInt(num) * 10; //int = 정수
		System.out.println(result);
		
		System.out.println(Double.parseDouble("3.14") + 10);
		
//		=====================================================
		
//		자료형 초기값
		int data = 0;
		double weight = 0.0;
		char input = ' ';
		String name = "";
		
//		null은 모든 클래스 타입의 초기값
		String hometown = null; //데이터가 비어있다는 표시를 하는 표시
		
		System.out.println(name + "호근"); //"호근"
		System.out.println(hometown + "창원"); //"null창원"
	}
}
