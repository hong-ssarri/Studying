package array;
import java.util.Scanner;

public class ArrayHomework1 {

	public static void main(String[] args) {

//		5개의 정수를 입력받고 배열에 담은 후 최댓값과 최솟값을 출력
		Scanner sc = new Scanner(System.in);
		
		int[] numbers = new int[5];
		int minNum = 0;
		int maxNum = 0;
		
		for (int i = 0; i < numbers.length; i++) {
			System.out.println(i + 1 + "번째 정수를 입력하세요");
			numbers[i] = sc.nextInt();
		}
		
		minNum = numbers[0];
		for (int i = 1; i < numbers.length; i++) {
			if(minNum > numbers[i]) {
				minNum = numbers[i];
			}
			if(maxNum < numbers[i]) {
				
				maxNum = numbers[i];
			}
		}
		
		System.out.println("최솟값은 " + minNum + ", 최댓값은 " + maxNum);
		
		
	}

}
