package array;

import java.util.Scanner;

public class ArrayHomework2 {
	public static void main(String[] args) {
	
//		사용자가 입력한 정수의 개수만큼 배열을 만든 후
//		그 개수만큼 정수를 입력받아 요소를 채운 후, 그 요소들의 평균 구하기
//		평균은 소수점 둘째자리까지 출력
		
		Scanner sc = new Scanner(System.in);
		int[] nums = null;
		int total = 0;
		
		System.out.println("몇 개만큼 배열을 만들래 >>");
		nums = new int[sc.nextInt()];
		
		//배열에 들어갈 내용 입력
		for (int i = 0; i < nums.length; i++) {
			System.out.println(i+1 + "번째 칸에 들어갈 숫자를 적어줘");
			nums[i] = sc.nextInt();
			
			total += nums[i];
		}
		
		//배열 출력 for문
		for (int i = 0; i < nums.length; i++) {
			System.out.printf(nums[i] + " ");
		}
		System.out.println("요소들의 평균: " + String.format("평균 : %.2f", (double)total / nums.length));
		
	}
}
