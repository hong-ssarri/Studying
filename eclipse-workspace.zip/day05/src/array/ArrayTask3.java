package array;

import java.util.Scanner;

public class ArrayTask3 {
	public static void main(String[] args) {
//		사용자에게 배열의 칸 수를 입력 받고
//		하나하나의 들어갈 값들도 전부 입력 받아 배열을 만들어라 
		
		Scanner sc = new Scanner(System.in);
		int[] datas = null;
		
		System.out.println("몇 개짜리 만들래?");
		datas = new int[sc.nextInt()];
		
		for (int i = 0; i < datas.length; i++) {
			System.out.println(i+1 + "번째 들어갈 숫자를 적어줘");
			datas[i] = sc.nextInt();
		}
		
		for (int i = 0; i < datas.length; i++) {
			System.out.print(datas[i] + " ");
		}
	}
}
