package control;

import java.util.Scanner;

public class WhileTest {
	public static void main(String[] args) {
//		while(true) {
//			System.out.println("내일은 우리 강의 없어요!");
//		}
		
//		while문을 for문처럼 사용해보기
		int count = 0;
		
//		while(count != 10) {
//			count++;
//			System.out.println(count + ". 류호근");
//		}
		
//		이런 느낌으로 사용!
		
		Scanner sc = new Scanner(System.in);
		int count = 0, num =0;
		while(true) {
			count++;
			System.out.println(count + ". 류호근");
			if(count == 10) {
				break;
			}
		}
		
	}
}
