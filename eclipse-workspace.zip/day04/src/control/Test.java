package control;

public class Test {

	public static void main(String[] args) {
		int i = 2;
		while(i <= 9) {
			int j = 1;
			while(j <= 9) {
				System.out.println(i + " * " + j + " = " + (i*j));
				j++;
			}
			i++;
			System.out.println("==========================");
		}
		
		
//		=============================================
		
		for(int a=2; a<=9; a++) {
			for(int b=1; b<=9; b++) {
				System.out.println(a + " * " + b + " = "
						+ "" + (a*b));
			}
			System.out.println("==========================");
		}
	}

}
