package array;

public class TDArray {

	public static void main(String[] args) {
//		for(int[] is : datas) {
//			for(int data : is) {
//				System.out.println(data);
//			}
//		}
	}

}
