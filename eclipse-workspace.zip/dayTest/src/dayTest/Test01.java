package dayTest;

class Student{
	//필드
	String name;
	int age;
	int score_korean;
	int score_math;
	int score_eng;
	
	//생성자
	Student(String name, int age, int score_korean, int score_math, int score_eng){
		this.name = name;
		this.age = age;
		this.score_korean = score_korean;
		this.score_math = score_math;
		this.score_eng = score_eng;
	}
	
	//메소드
	void printScore() {
		System.out.println("이름: " + name);
		System.out.println("나이: " + age);
		System.out.println("국어성적: " + score_korean);
		System.out.println("수학성적: " + score_math);
		System.out.println("영어성적: " + score_eng);
	}
}

public class Test01 {
	public static void main(String[] args) {

		Student student = new Student("홍길동", 30, 100, 30, 50);
		student.printScore();//인스턴스 메소드 호출
		
	}
}
