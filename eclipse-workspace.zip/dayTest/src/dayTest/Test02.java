package dayTest;

class People{
	//필드
	String name;
	int age;
	
	//메소드
	void printMyself() {
		System.out.println("이름: " + name);
		System.out.println("나이: " + age);
	}
}

class Students extends People{
	//필드
	int kor;
	int math;
	int eng;
	
	//생성자(constructor)
	Students (String name, int age, int kor, int math, int eng){
//		super.name = name;
//		super.age = age;
		this.kor = kor;
		this.math = math;
		this.eng = eng;
	}
	
	void printScore() {
		System.out.println("국어성적 :" + kor);
		System.out.println("이름은 뭐죠? : " + name);
	}
}

public class Test02 {
	public static void main(String[] args) {

		Students student= new Students("홍길동", 18, 300, 210, 400);
		student.printMyself();//부모 메소드 호출
		student.printScore();
		student.printScore();
		
		
	}
}
