package classTest;

import java.util.Scanner;

class Rocker{ //클래스 이름
	/* [필드] */
	String pw;

	/* *************************************************** */
	/* [생성자]
	 * 클래스를 가지고 객체를 생성하면 해당 객체는 메모리에 즉시 생성됨
	 * 이렇게 생성된 모든 객체는 모든 인스턴스 변수가 아직 초기화되지 않은 상태
	 * 
	 * 따라서 자바에서는 객체의 생성과 동시에 인스턴스 변수를 원하는 값으로 초기화할 수 있는 생성자(constructor)라는 메소드를 제공함
	 * 자바에서 생성자(constructor)의 이름은 해당 클래스의 이름과 같아야함
	 *   
	 * (참고) https://tcpschool.com/java/java_class_component */
	 
	Rocker(){
		pw = "0000";
	}
	
	Rocker(String pw){//생성자
		this.pw = pw;
	}
	
	/* *************************************************** */
	/* [메소드] 
	 * 클래스에서 메소드 : 어떠한 특정 작업을 수행하기 위한 명령문의 집합
	 * 모듈화로 인해 전체적은 코드의 가독성이 좋아짐 */
		
	void updatePw(String newPw) {//비밀번호 변경하는 메소드
		pw = newPw;
	}
}

class RockerService{
	Rocker choiceNewRocker(Scanner sc) { //메소드
		String pw = null;
		System.out.print("비밀번호 설정 >> ");
		pw = sc.next();
		return new Rocker(pw);
	}
	
	boolean choiceUsingRocker(String password, Scanner sc) {//메소드
		String pw = null;
		System.out.print("물건을 꺼내기 위해비밀번호를 입력해주세요 >> ");
		pw = sc.next();
		return password.equals(pw);//입력한 비밀번호가 일치하는지 확인 (.equals(pw));
	}
}

// ==== 메인 ==========================================
public class ClassTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		RockerService service = new RockerService();
		
		Rocker[] rockers = new Rocker[5]; //라커 5개 생성
		String mainMsg = "사물함을 이용해봅시다!";
		String choiceMsg = "사물함 선택 (0번 : 종료)";
		String choiceMenuMsg = "1. 물건 꺼내기\n2. 비밀번호 변경";
		int choice = 0; //선택값 초기화
		String pw = null; //패스워드값 초기화 ("" 또는 null)
		
		while(true) {
			System.out.println(mainMsg);
			System.out.println(choiceMsg);
			
			choice = sc.nextInt();
			
			//0 입력 시 종료
			if(choice == 0) {
				System.out.println("프로그램을 종료합니다.");
				break;
			}
			
			//사물함번호에 따른 switch문
			switch(choice) {
			case 1:
				if(rockers[0] != null) {
					
				}
				
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			default:
				break;
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
